import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:material_symbols_icons/symbols.dart';

import '../../../core/utils/video_utils.dart';
import '../../../routes/app_routes.dart';
import '../controllers/video_player_controller.dart';

class EnhancedVideoControls extends StatelessWidget {
  const EnhancedVideoControls({
    required this.videoTitle,
    this.videoPath,
    super.key,
  });

  final String videoTitle;
  final String? videoPath;

  @override
  Widget build(BuildContext context) {
    return GetX<VideoPlayerController>(
      builder: (controller) {
        if (!controller.isInitialized ||
            controller.videoPlayerController == null) {
          return const SizedBox.shrink();
        }

        return AnimatedBuilder(
          animation: controller.controlsAnimation,
          builder: (context, child) {
            return AnimatedOpacity(
              opacity: controller.controlsAnimation.value,
              duration: const Duration(milliseconds: 200),
              child: controller.isControlsVisible
                  ? _buildControlsContent(context, controller)
                  : const SizedBox.shrink(),
            );
          },
        );
      },
    );
  }

  Widget _buildControlsContent(
    BuildContext context,
    VideoPlayerController controller,
  ) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Colors.black.withValues(alpha: 0.8),
            Colors.transparent,
            Colors.transparent,
            Colors.black.withValues(alpha: 0.9),
          ],
          stops: const [0.0, 0.25, 0.75, 1.0],
        ),
      ),
      child: SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _TopControlBar(videoTitle: videoTitle, videoPath: videoPath),
            const Expanded(child: SizedBox()),
            _CenterPlayControls(),
            const Expanded(child: SizedBox()),
            _BottomControlBar(),
          ],
        ),
      ),
    );
  }
}

class _TopControlBar extends StatelessWidget {
  const _TopControlBar({required this.videoTitle, this.videoPath});

  final String videoTitle;
  final String? videoPath;

  /// Wrapper for button presses with haptic feedback
  void _onButtonPressed(VoidCallback callback) {
    HapticFeedback.selectionClick();
    callback();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
      child: Row(
        children: [
          _buildBackButton(context),
          const SizedBox(width: 16),
          Expanded(child: _buildTitleSection(theme)),
          const SizedBox(width: 16),
          _buildTopActions(),
        ],
      ),
    );
  }

  Widget _buildBackButton(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.5),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.white.withValues(alpha: 0.2)),
      ),
      child: IconButton(
        icon: const Icon(
          Symbols.arrow_back_ios_rounded,
          color: Colors.white,
          size: 20,
        ),
        onPressed: () => AppRoutes.goBack(),
        style: IconButton.styleFrom(
          padding: const EdgeInsets.all(12),
          minimumSize: const Size(48, 48),
        ),
      ),
    );
  }

  Widget _buildTitleSection(ThemeData theme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          videoTitle,
          style: theme.textTheme.titleLarge?.copyWith(
            color: Colors.white,
            fontWeight: FontWeight.w600,
            letterSpacing: -0.5,
            height: 1.2,
          ),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        if (videoPath != null) ...[
          const SizedBox(height: 4),
          Builder(
            builder: (context) {
              final controller = Get.find<VideoPlayerController>();
              return Text(
                _getVideoInfo(controller),
                style: theme.textTheme.bodySmall?.copyWith(
                  color: Colors.white.withValues(alpha: 0.8),
                  fontWeight: FontWeight.w400,
                ),
              );
            },
          ),
        ],
      ],
    );
  }

  Widget _buildTopActions() {
    return Row(
      children: [
        _buildActionButton(
          icon: Symbols.cast_rounded,
          onPressed: () => _showCastDialog(),
        ),
        const SizedBox(width: 8),
        Obx(() {
          final controller = Get.find<VideoPlayerController>();
          return _buildActionButton(
            icon: controller.isFullScreen
                ? Symbols.fullscreen_exit_rounded
                : Symbols.fullscreen_rounded,
            onPressed: () => _onButtonPressed(controller.toggleFullScreen),
          );
        }),
        const SizedBox(width: 8),
        _buildMenuButton(),
      ],
    );
  }

  Widget _buildActionButton({
    required IconData icon,
    required VoidCallback onPressed,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.5),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withValues(alpha: 0.2)),
      ),
      child: IconButton(
        icon: Icon(icon, color: Colors.white, size: 20),
        onPressed: onPressed,
        style: IconButton.styleFrom(
          padding: const EdgeInsets.all(10),
          minimumSize: const Size(40, 40),
        ),
      ),
    );
  }

  Widget _buildMenuButton() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.5),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withValues(alpha: 0.2)),
      ),
      child: PopupMenuButton<String>(
        icon: const Icon(
          Symbols.more_vert_rounded,
          color: Colors.white,
          size: 20,
        ),
        color: const Color(0xFF1C1B1F),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        elevation: 12,
        onSelected: _handleMenuAction,
        itemBuilder: (context) => [
          _buildMenuItem('info', Symbols.info_rounded, 'Video Info'),
          _buildMenuItem('share', Symbols.share_rounded, 'Share'),
        ],
        style: IconButton.styleFrom(
          padding: const EdgeInsets.all(10),
          minimumSize: const Size(40, 40),
        ),
      ),
    );
  }

  PopupMenuItem<String> _buildMenuItem(
    String value,
    IconData icon,
    String text,
  ) {
    return PopupMenuItem(
      value: value,
      child: Row(
        children: [
          Icon(icon, color: Colors.white.withValues(alpha: 0.9), size: 20),
          const SizedBox(width: 16),
          Text(
            text,
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.9),
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  String _getVideoInfo(VideoPlayerController controller) {
    if (controller.videoPlayerController == null) return '';

    final size = controller.videoPlayerController!.value.size;
    final duration = controller.videoPlayerController!.value.duration;

    return '${size.width.toInt()}×${size.height.toInt()} • ${VideoUtils.formatDuration(duration)}';
  }

  void _showCastDialog() {
    Get.dialog(
      AlertDialog(
        backgroundColor: Colors.grey[900],
        title: const Text(
          'Cast to Device',
          style: TextStyle(color: Colors.white),
        ),
        content: const Text(
          'No casting devices found nearby.',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: Text(
              'OK',
              style: TextStyle(
                color: Theme.of(Get.context!).colorScheme.primary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _handleMenuAction(String action) {
    final controller = Get.find<VideoPlayerController>();

    switch (action) {
      case 'info':
        _showVideoInfo(controller);
        break;
    }
  }

  void _showVideoInfo(VideoPlayerController controller) {
    if (controller.videoPlayerController == null) return;

    final videoController = controller.videoPlayerController!;
    final size = videoController.value.size;
    final duration = videoController.value.duration;

    Get.dialog(
      AlertDialog(
        backgroundColor: Colors.grey[900],
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text(
          'Video Information',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildInfoRow('Title', videoTitle),
            _buildInfoRow(
              'Resolution',
              '${size.width.toInt()}×${size.height.toInt()}',
            ),
            _buildInfoRow('Duration', VideoUtils.formatDuration(duration)),
            _buildInfoRow(
              'Aspect Ratio',
              videoController.value.aspectRatio.toStringAsFixed(2),
            ),
            if (videoPath != null) _buildInfoRow('Path', videoPath!),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: Text(
              'Close',
              style: TextStyle(
                color: Theme.of(Get.context!).colorScheme.primary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 90,
            child: Text(
              '$label:',
              style: TextStyle(
                color: Colors.white.withValues(alpha: 0.7),
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(color: Colors.white, fontSize: 14),
            ),
          ),
        ],
      ),
    );
  }
}

class _CenterPlayControls extends StatelessWidget {
  /// Wrapper for button presses with haptic feedback
  void _onButtonPressed(VoidCallback callback) {
    HapticFeedback.selectionClick();
    callback();
  }

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<VideoPlayerController>();
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        _buildSeekButton(
          icon: Symbols.replay_10_rounded,
          onPressed: controller.seekBackward,
        ),
        _buildMainPlayButton(controller),
        _buildSeekButton(
          icon: Symbols.forward_10_rounded,
          onPressed: controller.seekForward,
        ),
      ],
    );
  }

  Widget _buildMainPlayButton(VideoPlayerController controller) {
    if (controller.videoPlayerController == null) {
      return const SizedBox.shrink();
    }

    return ValueListenableBuilder(
      valueListenable: controller.videoPlayerController!,
      builder: (context, value, child) {
        final isPlaying = value.isPlaying;
        return GestureDetector(
          onTap: () => _onButtonPressed(controller.togglePlayPause),
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.2),
              shape: BoxShape.circle,
              border: Border.all(
                color: Colors.white.withValues(alpha: 0.5),
                width: 2,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.3),
                  blurRadius: 20,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: Icon(
              isPlaying ? Symbols.pause_rounded : Symbols.play_arrow_rounded,
              color: Colors.white,
              size: 40,
            ),
          ),
        );
      },
    );
  }

  Widget _buildSeekButton({
    required IconData icon,
    required VoidCallback onPressed,
  }) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.15),
          shape: BoxShape.circle,
          border: Border.all(
            color: Colors.white.withValues(alpha: 0.3),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.2),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Icon(icon, color: Colors.white, size: 24),
      ),
    );
  }
}

class _BottomControlBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final controller = Get.find<VideoPlayerController>();
    return Container(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          _buildProgressSection(controller),
          const SizedBox(height: 20),
          _buildControlButtons(controller),
        ],
      ),
    );
  }

  Widget _buildProgressSection(VideoPlayerController controller) {
    return Builder(
      builder: (context) {
        final theme = Theme.of(context);
        final colorScheme = theme.colorScheme;

        return ValueListenableBuilder(
          valueListenable: controller.videoPlayerController!,
          builder: (context, value, child) {
            final position = value.position;
            final duration = value.duration;

            return Column(
              children: [
                SliderTheme(
                  data: SliderTheme.of(context).copyWith(
                    activeTrackColor: colorScheme.primary,
                    inactiveTrackColor: Colors.white.withValues(alpha: 0.3),
                    thumbColor: colorScheme.primary,
                    overlayColor: colorScheme.primary.withValues(alpha: 0.2),
                    thumbShape: const RoundSliderThumbShape(
                      enabledThumbRadius: 8,
                      elevation: 4,
                    ),
                    trackHeight: 4,
                    overlayShape: const RoundSliderOverlayShape(
                      overlayRadius: 16,
                    ),
                  ),
                  child: Slider(
                    value: duration.inMilliseconds > 0
                        ? position.inMilliseconds / duration.inMilliseconds
                        : 0.0,
                    onChanged: (value) {
                      final newPosition = Duration(
                        milliseconds: (value * duration.inMilliseconds).round(),
                      );
                      controller.seekTo(newPosition);
                    },
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      VideoUtils.formatDuration(position),
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.black.withValues(alpha: 0.5),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        '${controller.playbackSpeed}×',
                        style: TextStyle(
                          color: Colors.white.withValues(alpha: 0.9),
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    Text(
                      VideoUtils.formatDuration(duration),
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ],
            );
          },
        );
      },
    );
  }

  Widget _buildControlButtons(VideoPlayerController controller) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        Obx(
          () => _buildControlButton(
            icon: Symbols.volume_up_rounded,
            onPressed: controller.toggleVolumeSlider,
            isActive: controller.showVolumeSlider,
          ),
        ),
        Obx(
          () => _buildControlButton(
            icon: Symbols.brightness_6_rounded,
            onPressed: controller.toggleBrightnessSlider,
            isActive: controller.showBrightnessSlider,
          ),
        ),
        Obx(
          () => _buildControlButton(
            icon: Symbols.speed_rounded,
            onPressed: controller.toggleSpeedSelector,
            isActive: controller.showSpeedSelector,
          ),
        ),
        _buildControlButton(
          icon: Symbols.picture_in_picture_rounded,
          onPressed: () => _showPiPDialog(),
        ),
      ],
    );
  }

  Widget _buildControlButton({
    required IconData icon,
    required VoidCallback onPressed,
    bool isActive = false,
  }) {
    return Builder(
      builder: (context) {
        final theme = Theme.of(context);
        final colorScheme = theme.colorScheme;

        return Container(
          decoration: BoxDecoration(
            color: isActive
                ? colorScheme.primary.withValues(alpha: 0.2)
                : Colors.white.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: isActive
                  ? colorScheme.primary.withValues(alpha: 0.6)
                  : Colors.white.withValues(alpha: 0.3),
              width: 1.5,
            ),
          ),
          child: IconButton(
            icon: Icon(
              icon,
              color: isActive ? colorScheme.primary : Colors.white,
              size: 20,
            ),
            onPressed: onPressed,
            style: IconButton.styleFrom(
              padding: const EdgeInsets.all(12),
              minimumSize: const Size(44, 44),
            ),
          ),
        );
      },
    );
  }

  void _showPiPDialog() {
    Get.dialog(
      AlertDialog(
        backgroundColor: Colors.grey[900],
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text(
          'Picture in Picture',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
        ),
        content: const Text(
          'Picture-in-picture mode is not available on this device.',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: Text(
              'OK',
              style: TextStyle(
                color: Theme.of(Get.context!).colorScheme.primary,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
