import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../core/services/storage_service.dart';
import '../../../core/storage/local_storage.dart';

class LanguageController extends GetxController {
  final Rx<Locale> _locale = const Locale('en').obs;
  Locale get locale => _locale.value;

  final List<Locale> supportedLocales = const [
    Locale('en'),
    Locale('es'),
    Locale('fr'),
    Locale('de'),
  ];

  @override
  void onInit() {
    super.onInit();
    _loadLanguage();
  }

  Future<void> _loadLanguage() async {
    final storage = StorageService.to;
    final languageCode =
        storage.getUserPreference<String>(StorageKeys.languageCode) ?? 'en';
    final locale = Locale(languageCode);

    if (supportedLocales.contains(locale)) {
      _locale.value = locale;
      Get.updateLocale(locale);
    }
  }

  Future<void> setLanguage(Locale locale) async {
    if (supportedLocales.contains(locale)) {
      await StorageService.to.saveUserPreference(
        StorageKeys.languageCode,
        locale.languageCode,
      );
      _locale.value = locale;
      Get.updateLocale(locale);
    }
  }

  String getLanguageName(String languageCode) {
    switch (languageCode) {
      case 'en':
        return 'English';
      case 'es':
        return 'Español';
      case 'fr':
        return 'Français';
      case 'de':
        return 'Deutsch';
      default:
        return 'English';
    }
  }
}
