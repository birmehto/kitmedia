import 'package:flutter/material.dart';

import '../models/video_file.dart';
import 'unified_video_card.dart';

/// Enhanced video card that extends the unified card with additional features
class VideoCard extends StatelessWidget {
  const VideoCard({
    required this.video,
    required this.onTap,
    required this.onLongPress,
    this.isGridView = false,
    super.key,
  });

  final VideoFile video;
  final VoidCallback onTap;
  final VoidCallback onLongPress;
  final bool isGridView;

  @override
  Widget build(BuildContext context) {
    return UnifiedVideoCard(
      video: video,
      onTap: onTap,
      onLongPress: onLongPress,
      isGridView: isGridView,
    );
  }
}
