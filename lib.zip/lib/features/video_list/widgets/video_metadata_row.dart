import 'package:flutter/material.dart';
import 'package:material_symbols_icons/symbols.dart';

import '../../../core/utils/date_formatter.dart';

/// Reusable widget for displaying video metadata (duration, size, date)
class VideoMetadataRow extends StatelessWidget {
  const VideoMetadataRow({
    required this.duration,
    required this.size,
    this.date,
    this.isCompact = false,
    super.key,
  });

  final String duration;
  final String size;
  final DateTime? date;
  final bool isCompact;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final iconSize = isCompact ? 14.0 : 16.0;

    return Row(
      children: [
        Icon(
          Symbols.access_time_rounded,
          size: iconSize,
          color: theme.colorScheme.onSurfaceVariant,
        ),
        const SizedBox(width: 4),
        Text(
          duration,
          style: theme.textTheme.bodySmall?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(width: 12),
        Icon(
          Symbols.storage_rounded,
          size: iconSize,
          color: theme.colorScheme.onSurfaceVariant,
        ),
        const SizedBox(width: 4),
        Expanded(
          child: Text(
            size,
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
              fontWeight: FontWeight.w500,
            ),
            overflow: TextOverflow.ellipsis,
          ),
        ),
        if (date != null) ...[
          const SizedBox(width: 8),
          Icon(
            Symbols.calendar_today_rounded,
            size: iconSize - 2,
            color: theme.colorScheme.onSurfaceVariant.withValues(alpha: 0.7),
          ),
          const SizedBox(width: 4),
          Text(
            isCompact
                ? DateFormatter.formatCompactDate(date!)
                : DateFormatter.formatRelativeDate(date!),
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant.withValues(alpha: 0.8),
              fontSize: isCompact ? 10 : 12,
            ),
          ),
        ],
      ],
    );
  }
}
