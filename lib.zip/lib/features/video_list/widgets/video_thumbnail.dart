import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import 'package:material_symbols_icons/symbols.dart';
import 'package:video_thumbnail/video_thumbnail.dart' as vt;

import '../../../core/utils/logger.dart';

class VideoThumbnail extends StatelessWidget {
  const VideoThumbnail({
    required this.videoPath,
    this.width = 120,
    this.height = 90,
    this.borderRadius = 12,
    super.key,
  });

  final String videoPath;
  final double width;
  final double height;
  final double borderRadius;

  Future<Uint8List?> _getCachedThumbnail() async {
    try {
      final cacheKey = videoPath.hashCode.toString();
      final cacheFile = await DefaultCacheManager().getFileFromCache(cacheKey);

      if (cacheFile != null && await cacheFile.file.exists()) {
        appLog('Thumbnail cache hit for: $videoPath');
        return await cacheFile.file.readAsBytes();
      }

      final videoFile = File(videoPath);
      if (!videoFile.existsSync()) throw Exception('Video not found');

      final thumb = await vt.VideoThumbnail.thumbnailData(
        video: videoPath,
        imageFormat: vt.ImageFormat.JPEG,
        maxWidth: (width * 2).clamp(50.0, 1920.0).toInt(),
        maxHeight: (height * 2).clamp(50.0, 1080.0).toInt(),
        quality: 75,
        timeMs: 1000,
      ).timeout(const Duration(seconds: 10));

      if (thumb != null) {
        await DefaultCacheManager().putFile(cacheKey, thumb);
        appLog('Thumbnail cached for: $videoPath');
      }

      return thumb;
    } catch (e) {
      appLog('Thumbnail generation error: $e');
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return FutureBuilder<Uint8List?>(
      future: _getCachedThumbnail(),
      builder: (context, snapshot) {
        final isLoading = snapshot.connectionState == ConnectionState.waiting;
        final hasError = snapshot.hasError || snapshot.data == null;

        Widget child;
        if (isLoading) {
          child = _buildLoading(theme);
        } else if (hasError) {
          child = _buildError(theme);
        } else {
          child = Image.memory(
            snapshot.data!,
            width: double.infinity,
            height: double.infinity,
            fit: BoxFit.cover,
            errorBuilder: (_, _, _) => _buildError(theme),
          );
        }

        return Container(
          width: width,
          height: height,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(borderRadius),
            color: theme.colorScheme.surfaceContainerHighest,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.1),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(borderRadius),
            child: Stack(
              fit: StackFit.expand,
              children: [child, _buildGradient(), _buildPlayOverlay()],
            ),
          ),
        );
      },
    );
  }

  /// Cached loading indicator
  Widget _buildLoading(ThemeData theme) => const Center(
    child: SizedBox(
      width: 28,
      height: 28,
      child: CircularProgressIndicator(strokeWidth: 2.5),
    ),
  );

  Widget _buildError(ThemeData theme) => ColoredBox(
    color: theme.colorScheme.errorContainer,
    child: Icon(
      Symbols.video_file,
      size: 32,
      color: theme.colorScheme.onErrorContainer,
    ),
  );

  Widget _buildGradient() => Container(
    decoration: BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Colors.transparent, Colors.black.withValues(alpha: 0.3)],
        stops: const [0.6, 1.0],
      ),
    ),
  );

  Widget _buildPlayOverlay() => Center(
    child: Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.6),
        shape: BoxShape.circle,
        border: Border.all(
          color: Colors.white.withValues(alpha: 0.8),
          width: 2,
        ),
      ),
      child: const Icon(
        Symbols.play_arrow_rounded,
        color: Colors.white,
        size: 20,
      ),
    ),
  );
}
