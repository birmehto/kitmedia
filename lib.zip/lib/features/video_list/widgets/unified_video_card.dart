import 'package:flutter/material.dart';
import 'package:material_symbols_icons/symbols.dart';

import '../../../core/widgets/common/quality_badge.dart';
import '../../../core/widgets/common/styled_icon_button.dart';
import '../models/video_file.dart';
import 'video_metadata_row.dart';
import 'video_thumbnail.dart';

/// A single reusable video card that adapts to both list and grid layouts.
class UnifiedVideoCard extends StatelessWidget {
  const UnifiedVideoCard({
    required this.video,
    required this.onTap,
    super.key,
    this.onLongPress,
    this.isGridView = false,
    this.showQualityBadge = true,
    this.showActionButton = true,
  });

  final VideoFile video;
  final VoidCallback onTap;
  final VoidCallback? onLongPress;
  final bool isGridView;
  final bool showQualityBadge;
  final bool showActionButton;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      elevation: isGridView ? 3 : 2,
      margin: EdgeInsets.symmetric(
        horizontal: isGridView ? 8 : 16,
        vertical: isGridView ? 8 : 6,
      ),
      shadowColor: theme.colorScheme.shadow.withValues(alpha: 0.1),
      surfaceTintColor: theme.colorScheme.surfaceTint,
      child: InkWell(
        onTap: onTap,
        onLongPress: onLongPress,
        borderRadius: BorderRadius.circular(12),
        child: isGridView ? _buildGridLayout(theme) : _buildListLayout(theme),
      ),
    );
  }

  /// ----------- LIST VIEW ------------
  Widget _buildListLayout(ThemeData theme) => Padding(
    padding: const EdgeInsets.all(12),
    child: Row(
      children: [
        VideoThumbnail(
          videoPath: video.path,
          width: 100,
          height: 75,
          borderRadius: 8,
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildTitle(theme.textTheme.titleMedium!, theme),
              const SizedBox(height: 6),
              VideoMetadataRow(
                duration: video.durationString,
                size: video.sizeString,
                date: video.lastModified,
              ),
              if (showQualityBadge)
                Align(
                  alignment: Alignment.centerRight,
                  child: Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: QualityBadge(fileSize: video.size),
                  ),
                ),
            ],
          ),
        ),
        if (showActionButton)
          StyledIconButton(
            icon: Symbols.more_vert_rounded,
            onPressed: onLongPress,
            size: 20,
            tooltip: 'More options',
          ),
      ],
    ),
  );

  /// ----------- GRID VIEW ------------
  Widget _buildGridLayout(ThemeData theme) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Expanded(
        flex: 3,
        child: Stack(
          children: [
            Positioned.fill(
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: VideoThumbnail(videoPath: video.path, borderRadius: 8),
              ),
            ),
            if (showQualityBadge)
              Positioned(
                top: 6,
                right: 6,
                child: QualityBadge(fileSize: video.size),
              ),
          ],
        ),
      ),
      Expanded(
        flex: 2,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildTitle(theme.textTheme.titleSmall!, theme),
              const Spacer(),
              VideoMetadataRow(
                duration: video.durationString,
                size: video.sizeString,
                isCompact: true,
              ),
            ],
          ),
        ),
      ),
    ],
  );

  /// Common title widget for both layouts
  Widget _buildTitle(TextStyle style, ThemeData theme) => Text(
    video.name,
    maxLines: 2,
    overflow: TextOverflow.ellipsis,
    style: style.copyWith(
      fontWeight: FontWeight.w600,
      color: theme.colorScheme.onSurface,
    ),
  );
}
