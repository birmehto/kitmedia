import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:material_symbols_icons/symbols.dart';

import '../../../core/widgets/common/empty_state.dart';
import '../../../core/widgets/common/loading_indicator.dart';
import '../../../routes/app_routes.dart';
import '../controllers/video_controller.dart';
import '../models/video_file.dart';
import '../widgets/video_card.dart';

class VideoListScreen extends StatefulWidget {
  const VideoListScreen({super.key});

  @override
  State<VideoListScreen> createState() => _VideoListScreenState();
}

class _VideoListScreenState extends State<VideoListScreen> {
  final TextEditingController _searchController = TextEditingController();
  final VideoController videoController = Get.find<VideoController>();

  @override
  void initState() {
    super.initState();
    // Start scanning when the screen loads
    WidgetsBinding.instance.addPostFrameCallback((_) {
      videoController.scanVideos();
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: theme.colorScheme.primaryContainer,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                Symbols.video_library_rounded,
                color: theme.colorScheme.onPrimaryContainer,
                size: 24,
              ),
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'app_name'.tr,
                  style: theme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w700,
                    color: theme.colorScheme.onSurface,
                  ),
                ),
                Obx(
                  () => Text(
                    '${videoController.filteredVideos.length} videos',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
        actions: [
          // Search button
          IconButton(
            icon: const Icon(Symbols.search_rounded),
            onPressed: _showSearchDialog,
            tooltip: 'search_videos'.tr,
          ),
          const SizedBox(width: 4),
          IconButton(
            icon: const Icon(Symbols.settings_rounded),
            onPressed: () {
              Get.toNamed(AppRoutes.settings);
            },
            tooltip: 'search_videos'.tr,
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: Column(
        children: [
          // Search bar
          Obx(() {
            if (videoController.searchQuery.isNotEmpty) {
              return _buildSearchBar();
            }
            return const SizedBox.shrink();
          }),

          // Video list
          Expanded(
            child: Obx(() {
              if (videoController.isLoading) {
                return LoadingIndicator(message: 'loading'.tr);
              }

              if (videoController.errorMessage.isNotEmpty) {
                return _buildErrorState(videoController.errorMessage);
              }

              return _buildVideoList(videoController.filteredVideos);
            }),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
      child: SearchBar(
        controller: _searchController,
        hintText: 'search_videos'.tr,
        hintStyle: WidgetStateProperty.all(
          theme.textTheme.bodyLarge?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
        textStyle: WidgetStateProperty.all(
          theme.textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w500),
        ),
        leading: Icon(
          Symbols.search_rounded,
          color: theme.colorScheme.onSurfaceVariant,
        ),
        trailing: [
          IconButton(
            icon: Icon(
              Symbols.clear_rounded,
              color: theme.colorScheme.onSurfaceVariant,
            ),
            onPressed: () {
              _searchController.clear();
              videoController.clearSearch();
            },
          ),
        ],
        elevation: WidgetStateProperty.all(2),
        shadowColor: WidgetStateProperty.all(
          theme.colorScheme.shadow.withValues(alpha: 0.1),
        ),
        shape: WidgetStateProperty.all(
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        ),
        onChanged: (query) {
          videoController.updateSearchQuery(query);
        },
      ),
    );
  }

  Widget _buildVideoList(List<VideoFile> videos) {
    if (videos.isEmpty) {
      return EmptyState(
        icon: Symbols.video_library,
        title: 'no_videos_found'.tr,
        subtitle: 'Try refreshing or check your storage permissions',
        action: FilledButton.icon(
          onPressed: () => videoController.refresh(),
          icon: const Icon(Symbols.refresh_rounded),
          label: Text('refresh'.tr),
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(0, 12, 0, 24),
      itemCount: videos.length,
      itemBuilder: (context, index) {
        final video = videos[index];
        return VideoCard(
          video: video,
          // isGridView: false,
          onTap: () => _playVideo(video),
          onLongPress: () => _showVideoOptions(video),
        );
      },
    );
  }

  Widget _buildErrorState(String error) {
    return EmptyState(
      icon: Symbols.error_outline,
      title: 'error_occurred'.tr,
      subtitle: error,
      action: FilledButton.icon(
        onPressed: () => videoController.refresh(),
        icon: const Icon(Symbols.refresh),
        label: Text('retry'.tr),
      ),
    );
  }

  void _showSearchDialog() {
    final theme = Theme.of(context);
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'search_videos'.tr,
          style: theme.textTheme.headlineSmall?.copyWith(
            fontWeight: FontWeight.w700,
          ),
        ),
        content: TextField(
          controller: _searchController,
          decoration: const InputDecoration(
            hintText: 'Enter video name or path...',
            prefixIcon: Icon(Symbols.search_rounded),
          ),
          style: theme.textTheme.bodyLarge?.copyWith(
            fontWeight: FontWeight.w500,
          ),
          onChanged: (query) {
            videoController.updateSearchQuery(query);
          },
        ),
        actions: [
          OutlinedButton(
            onPressed: () {
              _searchController.clear();
              videoController.clearSearch();
              Navigator.pop(context);
            },
            child: const Text('Clear'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Done'),
          ),
        ],
      ),
    );
  }

  void _showVideoOptions(VideoFile video) {
    final theme = Theme.of(context);
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => Container(
        padding: const EdgeInsets.symmetric(vertical: 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Handle bar for better UX
            Container(
              width: 40,
              height: 4,
              margin: const EdgeInsets.only(bottom: 20),
              decoration: BoxDecoration(
                color: theme.colorScheme.onSurfaceVariant.withValues(
                  alpha: 0.4,
                ),
                borderRadius: BorderRadius.circular(2),
              ),
            ),

            // Video title
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
              child: Text(
                video.name,
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ),

            const SizedBox(height: 16),

            // Action options with expressive styling
            ListTile(
              leading: Icon(
                Symbols.play_circle,
                color: theme.colorScheme.primary,
                size: 28,
              ),
              title: Text(
                'video_player'.tr,
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              subtitle: const Text('Start playback'),
              onTap: () {
                Navigator.pop(context);
                _playVideo(video);
              },
            ),

            ListTile(
              leading: Icon(
                Symbols.info_rounded,
                color: theme.colorScheme.secondary,
                size: 28,
              ),
              title: const Text('Video Details'),
              subtitle: const Text('View file information'),
              onTap: () {
                Navigator.pop(context);
                _showVideoDetails(video);
              },
            ),

            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  void _showVideoDetails(VideoFile video) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(video.name),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildDetailRow('Path', video.path),
            _buildDetailRow('Size', video.sizeString),
            _buildDetailRow('Modified', video.lastModified.toString()),
            if (video.duration != null)
              _buildDetailRow('Duration', video.durationString),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 80,
            child: Text(
              '$label:',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }

  void _playVideo(VideoFile video) {
    AppRoutes.navigateToVideoPlayer(
      videoPath: video.path,
      videoTitle: video.name,
    );
  }
}
