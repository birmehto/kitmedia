import 'package:flutter/material.dart';

/// Reusable themed container with consistent styling
class ThemedContainer extends StatelessWidget {
  const ThemedContainer({
    required this.child,
    this.backgroundColor,
    this.borderRadius = 12.0,
    this.padding = const EdgeInsets.all(16),
    this.margin = EdgeInsets.zero,
    this.elevation = 0,
    this.border,
    this.gradient,
    super.key,
  });

  final Widget child;
  final Color? backgroundColor;
  final double borderRadius;
  final EdgeInsets padding;
  final EdgeInsets margin;
  final double elevation;
  final Border? border;
  final Gradient? gradient;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    if (elevation > 0) {
      return Container(
        margin: margin,
        child: Material(
          elevation: elevation,
          borderRadius: BorderRadius.circular(borderRadius),
          color: backgroundColor ?? theme.colorScheme.surface,
          child: Container(
            padding: padding,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(borderRadius),
              border: border,
              gradient: gradient,
            ),
            child: child,
          ),
        ),
      );
    }

    return Container(
      margin: margin,
      padding: padding,
      decoration: BoxDecoration(
        color: backgroundColor ?? theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(borderRadius),
        border: border,
        gradient: gradient,
      ),
      child: child,
    );
  }
}
