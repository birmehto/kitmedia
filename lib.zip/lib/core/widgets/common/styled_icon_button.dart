import 'package:flutter/material.dart';

/// Reusable styled icon button with consistent theming
class StyledIconButton extends StatelessWidget {
  const StyledIconButton({
    required this.icon,
    required this.onPressed,
    this.backgroundColor,
    this.foregroundColor,
    this.size = 24.0,
    this.padding = const EdgeInsets.all(8),
    this.borderRadius = 8.0,
    this.tooltip,
    this.isCircular = false,
    super.key,
  });

  final IconData icon;
  final VoidCallback? onPressed;
  final Color? backgroundColor;
  final Color? foregroundColor;
  final double size;
  final EdgeInsets padding;
  final double borderRadius;
  final String? tooltip;
  final bool isCircular;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final effectiveBackgroundColor =
        backgroundColor ?? theme.colorScheme.surfaceContainerHighest;
    final effectiveForegroundColor =
        foregroundColor ?? theme.colorScheme.onSurfaceVariant;

    return Container(
      decoration: BoxDecoration(
        color: effectiveBackgroundColor,
        borderRadius: isCircular ? null : BorderRadius.circular(borderRadius),
        shape: isCircular ? BoxShape.circle : BoxShape.rectangle,
      ),
      child: IconButton(
        onPressed: onPressed,
        icon: Icon(icon),
        color: effectiveForegroundColor,
        iconSize: size,
        padding: padding,
        constraints: BoxConstraints(
          minWidth: size + padding.horizontal,
          minHeight: size + padding.vertical,
        ),
        tooltip: tooltip,
      ),
    );
  }
}
