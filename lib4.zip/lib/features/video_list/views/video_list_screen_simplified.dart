// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:material_symbols_icons/symbols.dart';

// import '../../../core/core.dart';
// import '../../../routes/app_routes.dart';
// import '../controllers/video_controller.dart';
// import '../models/video_file.dart';
// import '../widgets/search_dialog.dart';
// import '../widgets/video_details_dialog.dart';
// import '../widgets/video_options_sheet.dart';

// class VideoListScreenSimplified extends StatelessWidget {
//   const VideoListScreenSimplified({super.key});

//   VideoController get _controller => Get.find<VideoController>();

//   @override
//   Widget build(BuildContext context) {
//     _initializeIfNeeded();

//     return Scaffold(
//       appBar: _buildAppBar(context),
//       body: Obx(() => _buildBody(context)),
//       floatingActionButton: _buildRefreshFab(),
//     );
//   }

//   void _initializeIfNeeded() {
//     WidgetsBinding.instance.addPostFrameCallback((_) {
//       if (_controller.videos.isEmpty && !_controller.isLoading) {
//         _controller.scanVideos();
//       }
//     });
//   }

//   PreferredSizeWidget _buildAppBar(BuildContext context) {
//     return AppBar(
//       title: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Text('app_name'.tr),
//           Obx(
//             () => Text(
//               '${_controller.filteredVideos.length} videos',
//               style: Theme.of(context).textTheme.bodySmall,
//             ),
//           ),
//         ],
//       ),
//       actions: [
//         Obx(
//           () => IconButton(
//             icon: Icon(
//               _controller.searchQuery.isEmpty
//                   ? Symbols.search_rounded
//                   : Symbols.search_off_rounded,
//             ),
//             onPressed: () => _toggleSearch(context),
//           ),
//         ),
//         IconButton(
//           icon: const Icon(Symbols.settings_rounded),
//           onPressed: () => Get.toNamed(AppRoutes.settings),
//         ),
//       ],
//     );
//   }

//   Widget _buildBody(BuildContext context) {
//     if (_controller.isLoading) {
//       return LoadingIndicator(message: 'loading'.tr);
//     }

//     if (_controller.errorMessage.isNotEmpty) {
//       return _buildErrorState();
//     }

//     return Column(
//       children: [
//         if (_controller.searchQuery.isNotEmpty) _buildSearchBar(),
//         Expanded(child: _buildVideoList()),
//       ],
//     );
//   }

//   Widget _buildSearchBar() {
//     return Container(
//       margin: const EdgeInsets.all(16),
//       child: SearchBar(
//         hintText: 'search_videos'.tr,
//         leading: const Icon(Symbols.search_rounded),
//         trailing: [
//           IconButton(
//             icon: const Icon(Symbols.clear_rounded),
//             onPressed: _controller.clearSearch,
//           ),
//         ],
//         onChanged: _controller.updateSearchQuery,
//       ),
//     );
//   }

//   Widget _buildVideoList() {
//     final videos = _controller.filteredVideos;

//     if (videos.isEmpty) {
//       return EmptyState(
//         icon: Symbols.video_library,
//         title: 'no_videos_found'.tr,
//         subtitle: 'Try refreshing or check permissions',
//         action: FilledButton.icon(
//           onPressed: _controller.refresh,
//           icon: const Icon(Symbols.refresh_rounded),
//           label: Text('refresh'.tr),
//         ),
//       );
//     }

//     return ListView.builder(
//       padding: const EdgeInsets.only(bottom: 100),
//       itemCount: videos.length,
//       itemBuilder: (context, index) {
//         final video = videos[index];
//         return UnifiedVideoCard(
//           video: video,
//           onTap: () => _playVideo(video),
//           onLongPress: () => _showVideoOptions(context, video),
//         );
//       },
//     );
//   }

//   Widget _buildErrorState() {
//     return EmptyState(
//       icon: Symbols.error_outline,
//       title: 'error_occurred'.tr,
//       subtitle: _controller.errorMessage,
//       action: FilledButton.icon(
//         onPressed: _controller.refresh,
//         icon: const Icon(Symbols.refresh_rounded),
//         label: Text('retry'.tr),
//       ),
//     );
//   }

//   Widget _buildRefreshFab() {
//     return Obx(
//       () => AnimatedScale(
//         scale: _controller.isLoading ? 0.0 : 1.0,
//         duration: const Duration(milliseconds: 300),
//         child: FloatingActionButton.extended(
//           onPressed: _controller.refresh,
//           icon: const Icon(Symbols.refresh_rounded),
//           label: const Text('Refresh'),
//         ),
//       ),
//     );
//   }

//   void _toggleSearch(BuildContext context) {
//     if (_controller.searchQuery.isEmpty) {
//       _showSearchDialog(context);
//     } else {
//       _controller.clearSearch();
//     }
//   }

//   void _showSearchDialog(BuildContext context) {
//     showDialog(
//       context: context,
//       builder: (context) => SearchDialog(controller: _controller),
//     );
//   }

//   void _showVideoOptions(BuildContext context, VideoFile video) {
//     showModalBottomSheet(
//       context: context,
//       isScrollControlled: true,
//       showDragHandle: true,
//       builder: (context) => VideoOptionsSheet(
//         video: video,
//         onPlay: () => _playVideo(video),
//         onShowDetails: () => _showVideoDetails(context, video),
//         onDelete: () => _deleteVideo(video),
//       ),
//     );
//   }

//   void _showVideoDetails(BuildContext context, VideoFile video) {
//     showDialog(
//       context: context,
//       builder: (context) => VideoDetailsDialog(video: video),
//     );
//   }

//   void _playVideo(VideoFile video) {
//     AppRoutes.navigateToVideoPlayer(
//       videoPath: video.path,
//       videoTitle: video.name,
//     );
//   }

//   void _deleteVideo(VideoFile video) {
//     _controller.deleteVideo(video);
//   }
// }
