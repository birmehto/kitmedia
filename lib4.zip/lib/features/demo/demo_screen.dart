import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:material_symbols_icons/symbols.dart';

import '../../core/core.dart';
import '../settings/controllers/theme_controller.dart';

/// Demo screen showcasing all the optimized components
class DemoScreen extends StatelessWidget {
  const DemoScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Optimized Components Demo'),
        actions: [
          GetBuilder<ThemeController>(
            builder: (controller) => IconButton(
              icon: Icon(
                controller.isDarkMode(context)
                    ? Symbols.light_mode
                    : Symbols.dark_mode,
              ),
              onPressed: () => controller.toggleTheme(),
              tooltip: 'Toggle theme',
            ),
          ),
        ],
      ),
      body: ListView(
        padding: Responsive.getPadding(context),
        children: [
          // UI Constants Demo
          _buildSection(context, 'UI Constants', Symbols.straighten, [
            _buildConstantsDemo(theme),
          ]),

          const SizedBox(height: UIConstants.spacingXXLarge),

          // UI Factory Demo
          _buildSection(context, 'UI Factory Components', Symbols.widgets, [
            _buildUIFactoryDemo(theme),
          ]),

          const SizedBox(height: UIConstants.spacingXXLarge),

          // Responsive Demo
          _buildSection(context, 'Responsive Layout', Symbols.devices, [
            _buildResponsiveDemo(context),
          ]),

          const SizedBox(height: UIConstants.spacingXXLarge),

          // Snackbar Demo
          _buildSection(context, 'Snackbar Service', Symbols.notifications, [
            _buildSnackbarDemo(),
          ]),

          const SizedBox(height: UIConstants.spacingXXLarge),

          // Theme Demo
          _buildSection(context, 'Dynamic Theme', Symbols.palette, [
            _buildThemeDemo(),
          ]),
        ],
      ),
    );
  }

  Widget _buildSection(
    BuildContext context,
    String title,
    IconData icon,
    List<Widget> children,
  ) {
    final theme = Theme.of(context);

    return UIFactory.buildCard(
      theme: theme,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(UIConstants.spacingSmall),
                decoration: BoxDecoration(
                  color: theme.colorScheme.primaryContainer,
                  borderRadius: UIConstants.borderRadiusMediumAll,
                ),
                child: Icon(
                  icon,
                  color: theme.colorScheme.onPrimaryContainer,
                  size: UIConstants.iconSizeLarge,
                ),
              ),
              const SizedBox(width: UIConstants.spacingMedium),
              Text(
                title,
                style: theme.textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          const SizedBox(height: UIConstants.spacingLarge),
          ...children,
        ],
      ),
    );
  }

  Widget _buildConstantsDemo(ThemeData theme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Spacing Constants:',
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: UIConstants.spacingMedium),
        Wrap(
          spacing: UIConstants.spacingMedium,
          runSpacing: UIConstants.spacingSmall,
          children: [
            _buildSpacingBox('XS', UIConstants.spacingXSmall, theme),
            _buildSpacingBox('S', UIConstants.spacingSmall, theme),
            _buildSpacingBox('M', UIConstants.spacingMedium, theme),
            _buildSpacingBox('L', UIConstants.spacingLarge, theme),
            _buildSpacingBox('XL', UIConstants.spacingXLarge, theme),
            _buildSpacingBox('XXL', UIConstants.spacingXXLarge, theme),
          ],
        ),
        const SizedBox(height: UIConstants.spacingLarge),
        Text(
          'Border Radius Constants:',
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: UIConstants.spacingMedium),
        Wrap(
          spacing: UIConstants.spacingMedium,
          runSpacing: UIConstants.spacingSmall,
          children: [
            _buildRadiusBox('S', UIConstants.borderRadiusSmall, theme),
            _buildRadiusBox('M', UIConstants.borderRadiusMedium, theme),
            _buildRadiusBox('L', UIConstants.borderRadiusLarge, theme),
            _buildRadiusBox('XL', UIConstants.borderRadiusXLarge, theme),
            _buildRadiusBox('XXL', UIConstants.borderRadiusXXLarge, theme),
          ],
        ),
      ],
    );
  }

  Widget _buildSpacingBox(String label, double size, ThemeData theme) {
    return Column(
      children: [
        Container(
          width: 40,
          height: size,
          decoration: BoxDecoration(
            color: theme.colorScheme.primary,
            borderRadius: UIConstants.borderRadiusSmallAll,
          ),
        ),
        const SizedBox(height: UIConstants.spacingXSmall),
        Text(label, style: theme.textTheme.bodySmall),
      ],
    );
  }

  Widget _buildRadiusBox(String label, double radius, ThemeData theme) {
    return Column(
      children: [
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: theme.colorScheme.secondary,
            borderRadius: BorderRadius.circular(radius),
          ),
        ),
        const SizedBox(height: UIConstants.spacingXSmall),
        Text(label, style: theme.textTheme.bodySmall),
      ],
    );
  }

  Widget _buildUIFactoryDemo(ThemeData theme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Metadata Chips:',
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: UIConstants.spacingMedium),
        Wrap(
          spacing: UIConstants.spacingMedium,
          runSpacing: UIConstants.spacingSmall,
          children: [
            UIFactory.buildMetadataChip(
              icon: Symbols.schedule,
              text: '2:30',
              theme: theme,
            ),
            UIFactory.buildMetadataChip(
              icon: Symbols.storage,
              text: '125 MB',
              theme: theme,
            ),
            UIFactory.buildMetadataChip(
              icon: Symbols.hd,
              text: 'HD',
              theme: theme,
            ),
          ],
        ),
        const SizedBox(height: UIConstants.spacingLarge),
        Text(
          'Play Overlay:',
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: UIConstants.spacingMedium),
        Center(
          child: UIFactory.buildPlayOverlay(
            theme: theme,
            onTap: () => SnackbarService.showInfo('Play button tapped!'),
          ),
        ),
        const SizedBox(height: UIConstants.spacingLarge),
        Text(
          'Duration Badge:',
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: UIConstants.spacingMedium),
        UIFactory.buildDurationBadge(duration: '12:34', theme: theme),
      ],
    );
  }

  Widget _buildResponsiveDemo(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Current Breakpoint: ${_getCurrentBreakpoint(context)}',
          style: Theme.of(
            context,
          ).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: UIConstants.spacingMedium),
        Text('Screen Width: ${Responsive.getScreenWidth(context).toInt()}px'),
        Text(
          'Grid Count: ${Responsive.getGridCount(context, tablet: 2, desktop: 3)}',
        ),
        Text('Is Landscape: ${Responsive.isLandscape(context)}'),
        const SizedBox(height: UIConstants.spacingMedium),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: Responsive.getGridCount(
              context,
              mobile: 2,
              tablet: 3,
              desktop: 4,
            ),
            crossAxisSpacing: UIConstants.spacingSmall,
            mainAxisSpacing: UIConstants.spacingSmall,
            childAspectRatio: 2,
          ),
          itemCount: 6,
          itemBuilder: (context, index) => Container(
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primaryContainer,
              borderRadius: UIConstants.borderRadiusSmallAll,
            ),
            child: Center(
              child: Text(
                '${index + 1}',
                style: TextStyle(
                  color: Theme.of(context).colorScheme.onPrimaryContainer,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSnackbarDemo() {
    return Builder(
      builder: (context) => Wrap(
        spacing: UIConstants.spacingMedium,
        runSpacing: UIConstants.spacingSmall,
        children: [
          FilledButton.icon(
            onPressed: () => SnackbarService.showSuccess(
              'Success message!',
              context: context,
              actionLabel: 'Undo',
              onAction: () =>
                  SnackbarService.showInfo('Undo clicked!', context: context),
            ),
            icon: const Icon(Symbols.check_circle),
            label: const Text('Success'),
          ),
          FilledButton.tonalIcon(
            onPressed: () => SnackbarService.showError(
              'Error message!',
              context: context,
              actionLabel: 'Retry',
              onAction: () =>
                  SnackbarService.showInfo('Retry clicked!', context: context),
            ),
            icon: const Icon(Symbols.error),
            label: const Text('Error'),
          ),
          OutlinedButton.icon(
            onPressed: () => SnackbarService.showInfo(
              'Info message with a longer text to show how it wraps!',
              context: context,
            ),
            icon: const Icon(Symbols.info),
            label: const Text('Info'),
          ),
          FilledButton.icon(
            onPressed: () => SnackbarService.showWarning(
              'Warning message!',
              context: context,
            ),
            icon: const Icon(Symbols.warning),
            label: const Text('Warning'),
          ),
          ElevatedButton.icon(
            onPressed: () => SnackbarService.showCustom(
              message: 'Custom snackbar with custom colors!',
              context: context,
              icon: Symbols.star,
              backgroundColor: Colors.purple.shade100,
              textColor: Colors.purple.shade900,
              iconColor: Colors.purple.shade700,
              duration: const Duration(seconds: 2),
            ),
            icon: const Icon(Symbols.star),
            label: const Text('Custom'),
          ),
        ],
      ),
    );
  }

  Widget _buildThemeDemo() {
    return GetBuilder<ThemeController>(
      builder: (controller) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Current Theme: ${controller.themeModeString}',
            style: Get.theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          Text(
            'Dynamic Colors: ${controller.isDynamicColorEnabled ? "Enabled" : "Disabled"}',
          ),
          const SizedBox(height: UIConstants.spacingMedium),
          Wrap(
            spacing: UIConstants.spacingMedium,
            runSpacing: UIConstants.spacingSmall,
            children: [
              FilledButton.icon(
                onPressed: () => controller.toggleTheme(),
                icon: const Icon(Symbols.brightness_6),
                label: const Text('Toggle Theme'),
              ),
              OutlinedButton.icon(
                onPressed: () => controller.toggleDynamicColor(),
                icon: const Icon(Symbols.palette),
                label: const Text('Toggle Dynamic'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _getCurrentBreakpoint(BuildContext context) {
    if (Responsive.isLargeDesktop(context)) return 'Large Desktop';
    if (Responsive.isDesktop(context)) return 'Desktop';
    if (Responsive.isTablet(context)) return 'Tablet';
    return 'Mobile';
  }
}
