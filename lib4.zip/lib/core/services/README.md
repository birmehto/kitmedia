# SnackbarService Usage Guide

The `SnackbarService` provides a centralized way to show consistent snackbars throughout the app using Flutter's standard `ScaffoldMessenger`.

## Features

- **Consistent Styling**: All snackbars follow the same design patterns
- **Theme Integration**: Automatically uses current theme colors
- **Context Aware**: Works with both context-based and global usage
- **Action Support**: Optional action buttons with callbacks
- **Multiple Types**: Success, Error, Info, Warning, and Custom

## Basic Usage

### With Context (Recommended)
```dart
// In a widget with BuildContext
SnackbarService.showSuccess(
  'Operation completed successfully!',
  context: context,
);

SnackbarService.showError(
  'Something went wrong',
  context: context,
  actionLabel: 'Retry',
  onAction: () => retryOperation(),
);
```

### Global Usage (Fallback)
```dart
// When context is not available (uses GetX context)
SnackbarService.showInfo('Global info message');
SnackbarService.showWarning('Global warning message');
```

## Available Methods

### Success Snackbar
```dart
SnackbarService.showSuccess(
  'Data saved successfully!',
  context: context,
  actionLabel: 'View',
  onAction: () => navigateToData(),
);
```

### Error Snackbar
```dart
SnackbarService.showError(
  'Failed to load data',
  context: context,
  actionLabel: 'Retry',
  onAction: () => loadData(),
);
```

### Info Snackbar
```dart
SnackbarService.showInfo(
  'New update available',
  context: context,
  actionLabel: 'Update',
  onAction: () => startUpdate(),
);
```

### Warning Snackbar
```dart
SnackbarService.showWarning(
  'Low storage space',
  context: context,
  actionLabel: 'Clean',
  onAction: () => cleanStorage(),
);
```

### Custom Snackbar
```dart
SnackbarService.showCustom(
  message: 'Custom styled message',
  context: context,
  icon: Icons.star,
  backgroundColor: Colors.purple.shade100,
  textColor: Colors.purple.shade900,
  iconColor: Colors.purple.shade700,
  duration: Duration(seconds: 5),
  actionLabel: 'Action',
  onAction: () => customAction(),
);
```

### Convenience Method
```dart
// Quick way to show different types
SnackbarService.show(
  context,
  'Message text',
  type: SnackbarType.success, // or .error, .warning, .info
  actionLabel: 'Action',
  onAction: () => doSomething(),
);
```

## Integration with Controllers

### BaseController Integration
```dart
class MyController extends BaseController {
  Future<void> saveData() async {
    await executeWithLoading(() async {
      // Save operation
      return await api.saveData();
    }, successMessage: 'Data saved successfully!');
  }

  void showCustomMessage(BuildContext context) {
    showSuccess('Custom success message', context: context);
    showError('Custom error message', context: context);
    showInfo('Custom info message', context: context);
    showWarning('Custom warning message', context: context);
  }
}
```

### Error Handler Integration
```dart
// In widgets
ErrorHandler.showErrorSnackBar(context, 'Error message');
ErrorHandler.showSuccessSnackBar(context, 'Success message');
ErrorHandler.showInfoSnackBar(context, 'Info message');
ErrorHandler.showWarningSnackBar(context, 'Warning message');
```

## Styling

All snackbars automatically use:
- **UIConstants** for consistent spacing and border radius
- **Theme colors** for proper Material Design integration
- **Floating behavior** with rounded corners
- **Icons** for visual clarity
- **Proper text styling** with appropriate font weights

## Best Practices

1. **Always provide context when available** for better theme integration
2. **Use appropriate types** (success, error, info, warning) for semantic clarity
3. **Keep messages concise** but informative
4. **Use action buttons sparingly** and only when they add value
5. **Test with different themes** to ensure proper color contrast

## Migration from GetX Snackbars

### Before (GetX)
```dart
Get.snackbar(
  'Title',
  'Message',
  snackPosition: SnackPosition.BOTTOM,
  backgroundColor: Colors.red,
  colorText: Colors.white,
);
```

### After (SnackbarService)
```dart
SnackbarService.showError(
  'Message',
  context: context,
  actionLabel: 'Action',
  onAction: () => doSomething(),
);
```

## Benefits

- **Standard Flutter**: Uses ScaffoldMessenger instead of GetX-specific implementation
- **Better Integration**: Works seamlessly with Material Design
- **Consistent Styling**: All snackbars follow the same design patterns
- **Theme Aware**: Automatically adapts to light/dark themes and dynamic colors
- **Action Support**: Built-in support for action buttons with proper styling
- **Type Safety**: Enum-based type system for different snackbar types