import 'package:flutter/services.dart';

import '../../../core/utils/logger.dart';

/// Simple system controls implementation that works without external packages
class SimpleSystemControls {
  SimpleSystemControls._();
  static SimpleSystemControls? _instance;
  static SimpleSystemControls get instance =>
      _instance ??= SimpleSystemControls._();

  // Current values
  double _currentBrightness = 0.5;
  double _currentVolume = 0.5;

  // Getters
  double get currentBrightness => _currentBrightness;
  double get currentVolume => _currentVolume;

  /// Initialize the service
  Future<void> initialize() async {
    try {
      // Try to get current system brightness using platform channels
      const platform = MethodChannel('flutter/system_brightness');
      final brightness = await platform.invokeMethod<double>('getBrightness');
      _currentBrightness = brightness ?? 0.5;
    } catch (e) {
      appLog('Could not get system brightness: $e');
      _currentBrightness = 0.5;
    }

    try {
      // Try to get current system volume using platform channels
      const platform = MethodChannel('flutter/system_volume');
      final volume = await platform.invokeMethod<double>('getVolume');
      _currentVolume = volume ?? 0.5;
    } catch (e) {
      appLog('Could not get system volume: $e');
      _currentVolume = 0.5;
    }
  }

  /// Set system brightness (0.0 to 1.0)
  Future<void> setBrightness(double brightness) async {
    try {
      final clampedBrightness = brightness.clamp(0.0, 1.0);

      // Try to set system brightness using platform channels
      const platform = MethodChannel('flutter/system_brightness');
      await platform.invokeMethod('setBrightness', clampedBrightness);

      _currentBrightness = clampedBrightness;
    } catch (e) {
      appLog('Could not set system brightness: $e');
      // Still update our internal value for UI consistency
      _currentBrightness = brightness.clamp(0.0, 1.0);
    }
  }

  /// Set system volume (0.0 to 1.0)
  Future<void> setVolume(double volume) async {
    try {
      final clampedVolume = volume.clamp(0.0, 1.0);

      // Try to set system volume using platform channels
      const platform = MethodChannel('flutter/system_volume');
      await platform.invokeMethod('setVolume', clampedVolume);

      _currentVolume = clampedVolume;
    } catch (e) {
      appLog('Could not set system volume: $e');
      // Still update our internal value for UI consistency
      _currentVolume = volume.clamp(0.0, 1.0);
    }
  }

  /// Adjust brightness by delta (-1.0 to 1.0)
  Future<void> adjustBrightness(double delta) async {
    final newBrightness = (_currentBrightness + delta).clamp(0.0, 1.0);
    await setBrightness(newBrightness);
  }

  /// Adjust volume by delta (-1.0 to 1.0)
  Future<void> adjustVolume(double delta) async {
    final newVolume = (_currentVolume + delta).clamp(0.0, 1.0);
    await setVolume(newVolume);
  }

  /// Provide haptic feedback for better UX
  void provideFeedback() {
    HapticFeedback.selectionClick();
  }

  /// Dispose resources
  void dispose() {
    // Nothing to dispose in this simple implementation
  }
}
