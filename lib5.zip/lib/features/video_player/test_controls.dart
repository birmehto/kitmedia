import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

import 'services/simple_system_controls.dart';

/// Simple test widget to verify brightness and volume controls work
class TestControlsWidget extends StatefulWidget {
  const TestControlsWidget({super.key});

  @override
  State<TestControlsWidget> createState() => _TestControlsWidgetState();
}

class _TestControlsWidgetState extends State<TestControlsWidget> {
  late SimpleSystemControls _controls;
  double _brightness = 0.5;
  double _volume = 0.5;

  @override
  void initState() {
    super.initState();
    _initializeControls();
  }

  Future<void> _initializeControls() async {
    _controls = SimpleSystemControls.instance;
    await _controls.initialize();

    setState(() {
      _brightness = _controls.currentBrightness;
      _volume = _controls.currentVolume;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Test Brightness & Volume'),
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
      ),
      backgroundColor: Colors.black,
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Brightness Control
            Card(
              color: Colors.grey[900],
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    Row(
                      children: [
                        const Icon(
                          Icons.brightness_6,
                          color: Colors.orange,
                          size: 24,
                        ),
                        const SizedBox(width: 12),
                        const Text(
                          'Brightness',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const Spacer(),
                        Text(
                          '${(_brightness * 100).round()}%',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    SliderTheme(
                      data: SliderTheme.of(context).copyWith(
                        activeTrackColor: Colors.orange,
                        inactiveTrackColor: Colors.grey[700],
                        thumbColor: Colors.orange,
                        overlayColor: Colors.orange.withValues(alpha: 0.2),
                      ),
                      child: Slider(
                        value: _brightness,
                        onChanged: (value) async {
                          setState(() {
                            _brightness = value;
                          });
                          await _controls.setBrightness(value);
                          HapticFeedback.selectionClick();
                        },
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        ElevatedButton(
                          onPressed: () async {
                            await _controls.setBrightness(0.2);
                            setState(() {
                              _brightness = 0.2;
                            });
                            HapticFeedback.lightImpact();
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.grey[800],
                            foregroundColor: Colors.white,
                          ),
                          child: const Text('Low'),
                        ),
                        ElevatedButton(
                          onPressed: () async {
                            await _controls.setBrightness(0.5);
                            setState(() {
                              _brightness = 0.5;
                            });
                            HapticFeedback.lightImpact();
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.grey[800],
                            foregroundColor: Colors.white,
                          ),
                          child: const Text('Medium'),
                        ),
                        ElevatedButton(
                          onPressed: () async {
                            await _controls.setBrightness(1.0);
                            setState(() {
                              _brightness = 1.0;
                            });
                            HapticFeedback.lightImpact();
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.grey[800],
                            foregroundColor: Colors.white,
                          ),
                          child: const Text('High'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 32),

            // Volume Control
            Card(
              color: Colors.grey[900],
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Icon(
                          _volume > 0.5
                              ? Icons.volume_up
                              : _volume > 0
                              ? Icons.volume_down
                              : Icons.volume_off,
                          color: Colors.blue,
                          size: 24,
                        ),
                        const SizedBox(width: 12),
                        const Text(
                          'Volume',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const Spacer(),
                        Text(
                          '${(_volume * 100).round()}%',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    SliderTheme(
                      data: SliderTheme.of(context).copyWith(
                        activeTrackColor: Colors.blue,
                        inactiveTrackColor: Colors.grey[700],
                        thumbColor: Colors.blue,
                        overlayColor: Colors.blue.withValues(alpha: 0.2),
                      ),
                      child: Slider(
                        value: _volume,
                        onChanged: (value) async {
                          setState(() {
                            _volume = value;
                          });
                          await _controls.setVolume(value);
                          HapticFeedback.selectionClick();
                        },
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        ElevatedButton(
                          onPressed: () async {
                            await _controls.setVolume(0.0);
                            setState(() {
                              _volume = 0.0;
                            });
                            HapticFeedback.lightImpact();
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.grey[800],
                            foregroundColor: Colors.white,
                          ),
                          child: const Text('Mute'),
                        ),
                        ElevatedButton(
                          onPressed: () async {
                            await _controls.setVolume(0.5);
                            setState(() {
                              _volume = 0.5;
                            });
                            HapticFeedback.lightImpact();
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.grey[800],
                            foregroundColor: Colors.white,
                          ),
                          child: const Text('Medium'),
                        ),
                        ElevatedButton(
                          onPressed: () async {
                            await _controls.setVolume(1.0);
                            setState(() {
                              _volume = 1.0;
                            });
                            HapticFeedback.lightImpact();
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.grey[800],
                            foregroundColor: Colors.white,
                          ),
                          child: const Text('Max'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 32),

            // Instructions
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.grey[800],
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Instructions:',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    '• Use sliders to adjust brightness and volume\n'
                    '• Tap preset buttons for quick adjustments\n'
                    '• Changes should apply to system settings\n'
                    '• If controls don\'t work, platform channels may need setup',
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 14,
                      height: 1.4,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Helper function to navigate to test controls
void showTestControls() {
  Get.to(() => const TestControlsWidget());
}
