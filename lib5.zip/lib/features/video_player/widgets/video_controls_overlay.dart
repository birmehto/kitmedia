import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:material_symbols_icons/symbols.dart';

import '../../../core/widgets/common/loading_indicator.dart';
import '../controllers/video_player_controller.dart';
import 'enhanced_video_controls.dart';

class VideoControlsOverlay extends StatelessWidget {
  const VideoControlsOverlay({
    required this.videoTitle,
    this.videoPath,
    super.key,
  });

  final String videoTitle;
  final String? videoPath;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // Enhanced main controls
        EnhancedVideoControls(videoTitle: videoTitle, videoPath: videoPath),

        // Side sliders and overlays
        _buildSideOverlays(),

        // Speed selector
        _buildSpeedSelector(),

        // Buffering indicator
        _buildBufferingIndicator(),
      ],
    );
  }

  Widget _buildSideOverlays() {
    return GetX<VideoPlayerController>(
      builder: (controller) => Positioned.fill(
        child: Row(
          children: [
            // Brightness slider (left side)
            if (controller.showBrightnessSlider)
              _buildVerticalSlider(
                value: controller.brightness,
                onChanged: controller.setBrightness,
                icon: Symbols.brightness_6_rounded,
                label: 'Brightness',
                isLeft: true,
              ),

            const Spacer(),

            // Volume slider (right side)
            if (controller.showVolumeSlider)
              _buildVerticalSlider(
                value: controller.volume,
                onChanged: controller.setVolume,
                icon: Symbols.volume_up_rounded,
                label: 'Volume',
                isLeft: false,
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildVerticalSlider({
    required double value,
    required Function(double) onChanged,
    required IconData icon,
    required String label,
    required bool isLeft,
  }) {
    final theme = Theme.of(Get.context!);
    final colorScheme = theme.colorScheme;

    return Container(
      margin: EdgeInsets.only(
        left: isLeft ? 24 : 0,
        right: isLeft ? 0 : 24,
        top: 120,
        bottom: 180,
      ),
      padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.85),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: Colors.white.withValues(alpha: 0.2)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.3),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: colorScheme.primary.withValues(alpha: 0.2),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: colorScheme.primary, size: 20),
          ),
          const SizedBox(height: 12),
          Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 11,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: RotatedBox(
              quarterTurns: -1,
              child: SliderTheme(
                data: SliderTheme.of(Get.context!).copyWith(
                  activeTrackColor: colorScheme.primary,
                  inactiveTrackColor: Colors.white.withValues(alpha: 0.3),
                  thumbColor: colorScheme.primary,
                  overlayColor: colorScheme.primary.withValues(alpha: 0.2),
                  thumbShape: const RoundSliderThumbShape(elevation: 4),
                  trackHeight: 5,
                ),
                child: Slider(value: value, onChanged: onChanged),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: colorScheme.primary.withValues(alpha: 0.2),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              '${(value * 100).round()}%',
              style: TextStyle(
                color: colorScheme.primary,
                fontSize: 12,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSpeedSelector() {
    return GetX<VideoPlayerController>(
      builder: (controller) {
        if (!controller.showSpeedSelector) return const SizedBox.shrink();

        return Positioned(
          bottom: 140,
          right: 24,
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.black.withValues(alpha: 0.9),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.white.withValues(alpha: 0.2)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.3),
                  blurRadius: 16,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Symbols.speed_rounded,
                      color: Theme.of(Get.context!).colorScheme.primary,
                      size: 20,
                    ),
                    const SizedBox(width: 8),
                    const Text(
                      'Playback Speed',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                ...controller.playbackSpeeds.map((speed) {
                  final isSelected = controller.playbackSpeed == speed;
                  return GestureDetector(
                    onTap: () {
                      controller.setPlaybackSpeed(speed);
                      controller.toggleSpeedSelector();
                    },
                    child: Container(
                      width: 100,
                      padding: const EdgeInsets.symmetric(
                        vertical: 10,
                        horizontal: 16,
                      ),
                      margin: const EdgeInsets.symmetric(vertical: 2),
                      decoration: BoxDecoration(
                        color: isSelected
                            ? Theme.of(
                                Get.context!,
                              ).colorScheme.primary.withValues(alpha: 0.3)
                            : Colors.transparent,
                        borderRadius: BorderRadius.circular(12),
                        border: isSelected
                            ? Border.all(
                                color: Theme.of(
                                  Get.context!,
                                ).colorScheme.primary.withValues(alpha: 0.8),
                              )
                            : null,
                      ),
                      child: Text(
                        '$speed×',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: isSelected
                              ? Theme.of(Get.context!).colorScheme.primary
                              : Colors.white,
                          fontSize: 14,
                          fontWeight: isSelected
                              ? FontWeight.w700
                              : FontWeight.w500,
                        ),
                      ),
                    ),
                  );
                }),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildBufferingIndicator() {
    final theme = Theme.of(Get.context!);
    final colorScheme = theme.colorScheme;

    return GetX<VideoPlayerController>(
      builder: (controller) => controller.isBuffering
          ? Center(
              child: Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.black.withValues(alpha: 0.8),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: Colors.white.withValues(alpha: 0.2),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.3),
                      blurRadius: 16,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox(
                      width: 40,
                      height: 40,
                      child: LoadingIndicator(
                        color: colorScheme.primary,
                        // strokeWidth: 4,
                        // strokeCap: StrokeCap.round,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'Buffering...',
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            )
          : const SizedBox.shrink(),
    );
  }
}
