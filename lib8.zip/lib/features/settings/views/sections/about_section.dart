import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:material_symbols_icons/symbols.dart';

import '../../../../core/config/app_config.dart';
import '../widgets/settings_section.dart';
import '../widgets/settings_tile.dart';

class AboutSection extends StatelessWidget {
  const AboutSection({super.key});

  @override
  Widget build(BuildContext context) {
    return SettingsSection(
      title: 'About',
      icon: Symbols.info_rounded,
      children: [
        // App Version
        const SettingsTile(
          icon: Symbols.app_settings_alt_rounded,
          title: 'Version',
          subtitle: AppConfig.appVersion,
          showTrailing: false,
        ),

        // Supported Formats
        SettingsTile(
          icon: Symbols.video_library_rounded,
          title: 'Supported Formats',
          subtitle: AppConfig.supportedVideoExtensions.join(', '),
          showTrailing: false,
        ),

        // Build Number
        const SettingsTile(
          icon: Symbols.build_rounded,
          title: 'Build Number',
          subtitle: '${AppConfig.buildNumber}',
          showTrailing: false,
        ),

        // Developer
        SettingsTile(
          icon: Symbols.person_rounded,
          title: 'Developer',
          subtitle: 'KitMedia Team',
          onTap: () => _showDeveloperInfo(context),
        ),

        // License
        SettingsTile(
          icon: Symbols.gavel_rounded,
          title: 'License',
          subtitle: 'Open Source License',
          onTap: () => _showLicenseDialog(context),
        ),

        // Privacy Policy
        SettingsTile(
          icon: Symbols.policy_rounded,
          title: 'Privacy Policy',
          subtitle: 'View our privacy policy',
          onTap: () => _showPrivacyPolicy(context),
        ),

        // Terms of Service
        SettingsTile(
          icon: Symbols.description_rounded,
          title: 'Terms of Service',
          subtitle: 'View terms and conditions',
          onTap: () => _showTermsOfService(context),
        ),

        // Rate App
        SettingsTile(
          icon: Symbols.star_rounded,
          title: 'Rate App',
          subtitle: 'Rate us on the app store',
          onTap: () => _rateApp(),
        ),

        // Share App
        SettingsTile(
          icon: Symbols.share_rounded,
          title: 'Share App',
          subtitle: 'Share KitMedia with friends',
          onTap: () => _shareApp(),
        ),
      ],
    );
  }

  void _showDeveloperInfo(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Developer Information'),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('KitMedia Team'),
            SizedBox(height: 8),
            Text('A modern media player built with Flutter'),
            SizedBox(height: 16),
            Text('Contact: support@kitmedia.app'),
            Text('Website: www.kitmedia.app'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  void _showLicenseDialog(BuildContext context) {
    showLicensePage(
      context: context,
      applicationName: 'KitMedia',
      applicationVersion: AppConfig.appVersion,
      applicationLegalese: '© 2024 KitMedia Team',
    );
  }

  void _showPrivacyPolicy(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Privacy Policy'),
        content: const SingleChildScrollView(
          child: Text(
            'This is a placeholder for the privacy policy. '
            'In a real app, you would load the actual privacy policy content here.',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  void _showTermsOfService(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Terms of Service'),
        content: const SingleChildScrollView(
          child: Text(
            'This is a placeholder for the terms of service. '
            'In a real app, you would load the actual terms content here.',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  void _rateApp() {
    Get.snackbar(
      'Rate App',
      'This would open the app store for rating',
      snackPosition: SnackPosition.BOTTOM,
    );
    // In a real app, you would use url_launcher or store_redirect package
  }

  void _shareApp() {
    Get.snackbar(
      'Share App',
      'This would open the share dialog',
      snackPosition: SnackPosition.BOTTOM,
    );
    // In a real app, you would use the share_plus package
  }
}
