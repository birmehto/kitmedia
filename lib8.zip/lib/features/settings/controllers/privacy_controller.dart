import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PrivacyController extends GetxController {
  static const String _analyticsKey = 'analytics_enabled';
  static const String _crashReportingKey = 'crash_reporting_enabled';
  static const String _usageStatsKey = 'usage_stats_enabled';
  static const String _locationAccessKey = 'location_access_enabled';
  static const String _biometricLockKey = 'biometric_lock_enabled';
  static const String _incognitoModeKey = 'incognito_mode_enabled';

  final RxBool _analyticsEnabled = false.obs;
  final RxBool _crashReportingEnabled = true.obs;
  final RxBool _usageStatsEnabled = false.obs;
  final RxBool _locationAccessEnabled = false.obs;
  final RxBool _biometricLockEnabled = false.obs;
  final RxBool _incognitoModeEnabled = false.obs;

  // Getters
  bool get analyticsEnabled => _analyticsEnabled.value;
  bool get crashReportingEnabled => _crashReportingEnabled.value;
  bool get usageStatsEnabled => _usageStatsEnabled.value;
  bool get locationAccessEnabled => _locationAccessEnabled.value;
  bool get biometricLockEnabled => _biometricLockEnabled.value;
  bool get incognitoModeEnabled => _incognitoModeEnabled.value;

  @override
  void onInit() {
    super.onInit();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();

    _analyticsEnabled.value = prefs.getBool(_analyticsKey) ?? false;
    _crashReportingEnabled.value = prefs.getBool(_crashReportingKey) ?? true;
    _usageStatsEnabled.value = prefs.getBool(_usageStatsKey) ?? false;
    _locationAccessEnabled.value = prefs.getBool(_locationAccessKey) ?? false;
    _biometricLockEnabled.value = prefs.getBool(_biometricLockKey) ?? false;
    _incognitoModeEnabled.value = prefs.getBool(_incognitoModeKey) ?? false;

    update();
  }

  Future<void> setAnalytics(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_analyticsKey, enabled);
    _analyticsEnabled.value = enabled;
    update();
  }

  Future<void> setCrashReporting(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_crashReportingKey, enabled);
    _crashReportingEnabled.value = enabled;
    update();
  }

  Future<void> setUsageStats(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_usageStatsKey, enabled);
    _usageStatsEnabled.value = enabled;
    update();
  }

  Future<void> setLocationAccess(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_locationAccessKey, enabled);
    _locationAccessEnabled.value = enabled;
    update();
  }

  Future<void> setBiometricLock(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_biometricLockKey, enabled);
    _biometricLockEnabled.value = enabled;
    update();
  }

  Future<void> setIncognitoMode(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_incognitoModeKey, enabled);
    _incognitoModeEnabled.value = enabled;
    update();
  }

  Future<void> resetAllData() async {
    // Show confirmation dialog
    final confirmed = await Get.dialog<bool>(
      AlertDialog(
        title: const Text('Reset All Data'),
        content: const Text(
          'This will delete all app data including settings, cache, and preferences. This action cannot be undone.',
        ),
        actions: [
          TextButton(
            onPressed: () => Get.back(result: false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Get.back(result: true),
            style: TextButton.styleFrom(
              foregroundColor: Get.theme.colorScheme.error,
            ),
            child: const Text('Reset'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      try {
        final prefs = await SharedPreferences.getInstance();
        await prefs.clear();

        // Reset all controllers to default values
        _analyticsEnabled.value = false;
        _crashReportingEnabled.value = true;
        _usageStatsEnabled.value = false;
        _locationAccessEnabled.value = false;
        _biometricLockEnabled.value = false;
        _incognitoModeEnabled.value = false;

        update();

        Get.snackbar(
          'Data Reset',
          'All app data has been reset to defaults',
          snackPosition: SnackPosition.BOTTOM,
        );
      } catch (e) {
        Get.snackbar(
          'Error',
          'Failed to reset data: $e',
          snackPosition: SnackPosition.BOTTOM,
        );
      }
    }
  }
}
