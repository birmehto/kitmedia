import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PlaybackController extends GetxController {
  static const String _autoPlayKey = 'auto_play_enabled';
  static const String _loopVideoKey = 'loop_video_enabled';
  static const String _playbackSpeedKey = 'playback_speed';
  static const String _skipDurationKey = 'skip_duration';
  static const String _volumeKey = 'default_volume';
  static const String _brightnessKey = 'default_brightness';

  final RxBool _autoPlayEnabled = true.obs;
  final RxBool _loopVideoEnabled = false.obs;
  final RxDouble _playbackSpeed = 1.0.obs;
  final RxInt _skipDuration = 10.obs; // seconds
  final RxDouble _defaultVolume = 1.0.obs;
  final RxDouble _defaultBrightness = 0.5.obs;

  // Getters
  bool get autoPlayEnabled => _autoPlayEnabled.value;
  bool get loopVideoEnabled => _loopVideoEnabled.value;
  double get playbackSpeed => _playbackSpeed.value;
  int get skipDuration => _skipDuration.value;
  double get defaultVolume => _defaultVolume.value;
  double get defaultBrightness => _defaultBrightness.value;

  final List<double> availableSpeeds = [0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 2.0];
  final List<int> availableSkipDurations = [5, 10, 15, 30, 60];

  @override
  void onInit() {
    super.onInit();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();

    _autoPlayEnabled.value = prefs.getBool(_autoPlayKey) ?? true;
    _loopVideoEnabled.value = prefs.getBool(_loopVideoKey) ?? false;
    _playbackSpeed.value = prefs.getDouble(_playbackSpeedKey) ?? 1.0;
    _skipDuration.value = prefs.getInt(_skipDurationKey) ?? 10;
    _defaultVolume.value = prefs.getDouble(_volumeKey) ?? 1.0;
    _defaultBrightness.value = prefs.getDouble(_brightnessKey) ?? 0.5;

    update();
  }

  Future<void> setAutoPlay(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_autoPlayKey, enabled);
    _autoPlayEnabled.value = enabled;
    update();
  }

  Future<void> setLoopVideo(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_loopVideoKey, enabled);
    _loopVideoEnabled.value = enabled;
    update();
  }

  Future<void> setPlaybackSpeed(double speed) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_playbackSpeedKey, speed);
    _playbackSpeed.value = speed;
    update();
  }

  Future<void> setSkipDuration(int duration) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_skipDurationKey, duration);
    _skipDuration.value = duration;
    update();
  }

  Future<void> setDefaultVolume(double volume) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_volumeKey, volume);
    _defaultVolume.value = volume;
    update();
  }

  Future<void> setDefaultBrightness(double brightness) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_brightnessKey, brightness);
    _defaultBrightness.value = brightness;
    update();
  }

  String getSpeedString(double speed) {
    if (speed == 1.0) return 'Normal';
    return '${speed}x';
  }

  String getSkipDurationString(int duration) {
    if (duration < 60) return '${duration}s';
    return '${duration ~/ 60}m';
  }
}
