import 'dart:io';
import 'package:get/get.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class StorageController extends GetxController {
  static const String _cacheEnabledKey = 'cache_enabled';
  static const String _maxCacheSizeKey = 'max_cache_size';
  static const String _autoDeleteKey = 'auto_delete_enabled';
  static const String _autoDeleteDaysKey = 'auto_delete_days';

  final RxBool _cacheEnabled = true.obs;
  final RxInt _maxCacheSize = 500.obs; // MB
  final RxBool _autoDeleteEnabled = false.obs;
  final RxInt _autoDeleteDays = 7.obs;
  final RxString _currentCacheSize = '0 MB'.obs;
  final RxString _availableStorage = '0 GB'.obs;

  // Getters
  bool get cacheEnabled => _cacheEnabled.value;
  int get maxCacheSize => _maxCacheSize.value;
  bool get autoDeleteEnabled => _autoDeleteEnabled.value;
  int get autoDeleteDays => _autoDeleteDays.value;
  String get currentCacheSize => _currentCacheSize.value;
  String get availableStorage => _availableStorage.value;

  final List<int> availableCacheSizes = [100, 250, 500, 1000, 2000]; // MB
  final List<int> availableDeleteDays = [1, 3, 7, 14, 30];

  @override
  void onInit() {
    super.onInit();
    _loadSettings();
    _updateStorageInfo();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();

    _cacheEnabled.value = prefs.getBool(_cacheEnabledKey) ?? true;
    _maxCacheSize.value = prefs.getInt(_maxCacheSizeKey) ?? 500;
    _autoDeleteEnabled.value = prefs.getBool(_autoDeleteKey) ?? false;
    _autoDeleteDays.value = prefs.getInt(_autoDeleteDaysKey) ?? 7;

    update();
  }

  Future<void> _updateStorageInfo() async {
    try {
      // Get cache directory size
      final cacheDir = await getTemporaryDirectory();
      final cacheSize = await _getDirectorySize(cacheDir);
      _currentCacheSize.value = _formatBytes(cacheSize);

      // Get available storage
      // This is a simplified approach - in a real app you might want to use
      // platform-specific methods to get actual available storage
      _availableStorage.value = 'Available'; // Placeholder

      update();
    } catch (e) {
      // Handle error silently
    }
  }

  Future<int> _getDirectorySize(Directory directory) async {
    int size = 0;
    try {
      await for (final entity in directory.list(recursive: true)) {
        if (entity is File) {
          size += await entity.length();
        }
      }
    } catch (e) {
      // Handle error silently
    }
    return size;
  }

  String _formatBytes(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    if (bytes < 1024 * 1024 * 1024) {
      return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    }
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
  }

  Future<void> setCacheEnabled(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_cacheEnabledKey, enabled);
    _cacheEnabled.value = enabled;
    update();
  }

  Future<void> setMaxCacheSize(int size) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_maxCacheSizeKey, size);
    _maxCacheSize.value = size;
    update();
  }

  Future<void> setAutoDelete(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_autoDeleteKey, enabled);
    _autoDeleteEnabled.value = enabled;
    update();
  }

  Future<void> setAutoDeleteDays(int days) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_autoDeleteDaysKey, days);
    _autoDeleteDays.value = days;
    update();
  }

  Future<void> clearCache() async {
    try {
      final cacheDir = await getTemporaryDirectory();
      if (await cacheDir.exists()) {
        await cacheDir.delete(recursive: true);
        await cacheDir.create();
      }
      await _updateStorageInfo();
      Get.snackbar(
        'Cache Cleared',
        'All cached files have been removed',
        snackPosition: SnackPosition.BOTTOM,
      );
    } catch (e) {
      Get.snackbar(
        'Error',
        'Failed to clear cache: $e',
        snackPosition: SnackPosition.BOTTOM,
      );
    }
  }

  String getCacheSizeString(int size) {
    if (size >= 1000) return '${size ~/ 1000} GB';
    return '$size MB';
  }

  String getAutoDeleteString(int days) {
    if (days == 1) return '1 day';
    return '$days days';
  }
}
